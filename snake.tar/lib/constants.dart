const int NUM_COLS = 10;
const int NUM_ROWS = 10;

const int DELTA_T_MS = 500;