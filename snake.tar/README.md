[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/MxgikXrxdyg/0.jpg)](https://www.youtube.com/watch?v=MxgikXrxdyg)

- Build the snake game in Flutter from scratch
